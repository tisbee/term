//
//  HeaderCollectionReusableView.m
//  AffdexMe
//
//  Created by boisy on 8/29/15.
//  Copyright (c) 2015 Affectiva. All rights reserved.
//

#import "HeaderCollectionReusableView.h"

@implementation HeaderCollectionReusableView

@end
