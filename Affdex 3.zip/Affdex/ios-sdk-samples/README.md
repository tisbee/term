Affdex Sample Code for the Affdex SDK for iOS
=============================================

Welcome to our repository on GitHub! Here you will find example code to get you started with our Affdex SDK for iOS and get you started emotion-enabling you own app!

AffdexMe
--------

AffdexMe is a simple app that uses the camera on your iOS device to view and mimic your facial expressions with icons.

In order to use the project, you will need to:
- Obtain the Affdex SDK for iOS at http://www.affdex.com/sdk.
- Copy the SDK archive file into the frameworks folder and dearchive it there.
- Add the license file that you receive from Affectiva to the project as 'sdk.license'.

